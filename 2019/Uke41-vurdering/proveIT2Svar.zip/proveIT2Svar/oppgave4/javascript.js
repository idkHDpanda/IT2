let f = Number(prompt("Skriv inn fahrenheit så gjør vi det om til celsius!"))
alert(f + " fahrenheit "+ "blir til ca. " + Math.ceil((f-32)/1.8) + " celsius")
