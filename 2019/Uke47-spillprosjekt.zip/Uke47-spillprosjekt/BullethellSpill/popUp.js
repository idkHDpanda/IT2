class PopUp{
  constructor(x,y){
    this.x = 20;
    this.y = 30;
    this.w = 55
    this.h = 55;
  }
  tegn(){
    rect(this.x, thus.y, this.w, this.h);
    text();
  }
}
