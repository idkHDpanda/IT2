//x skal bli 5 og y skal bli 2

let x;
let y;
let svar1 = 7;
let svar2 = 2;
